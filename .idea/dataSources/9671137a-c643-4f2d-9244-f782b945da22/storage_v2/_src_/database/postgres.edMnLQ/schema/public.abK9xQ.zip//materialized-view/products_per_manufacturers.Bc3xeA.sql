create materialized view products_per_manufacturers as
SELECT p.manufacturer_id,
       count(p.id) AS num_products
FROM product p
         JOIN manufacturers m ON m.id = p.manufacturer_id
GROUP BY p.manufacturer_id;

alter materialized view products_per_manufacturers owner to postgres;

